package bogget.studycraft;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class StudycraftClient implements ClientModInitializer {
    private static class_304 configKeyBinding;
    
    @Override
    public void onInitializeClient() {
        // Register networking handlers
        StudycraftNetworking.registerClientHandlers();
        
        // Register key binding
        configKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.studycraft.config",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_Y, // Default to Y key
            "StudyCraft"
        ));
        
        // Register tick event to check for key press
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (configKeyBinding.method_1436()) {
                if (client.field_1724 != null) {
                    client.method_1507(new StudycraftConfigScreen(null));
                }
            }
        });
    }
}