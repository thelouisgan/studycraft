package bogget.studycraft;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_437;
import net.minecraft.class_5481;
import java.util.ArrayList;

public class QuizScreen extends class_437 {
    private final QuestionBank.QuizData quizData;
    private final List<String> answers;
    private final int correctAnswerIndex;
    
    // Variables for the result display
    private boolean showingResult = false;
    private boolean isCorrect = false;
    private int selectedAnswerIndex = -1;
    private long resultDisplayStartTime = 0;
    private static final long RESULT_DISPLAY_DURATION = 3000; // 3 seconds in milliseconds
    
    // Custom answer panel (replacing buttons)
    private List<AnswerPanel> answerPanels = new ArrayList<>();
    
    // Grid layout settings
    private static final int GRID_COLUMNS = 2;
    private static final int GRID_ROWS = 2;
    private static final int PANEL_PADDING = 15;
    private static final int PANEL_MARGIN = 10;
    
    public QuizScreen(QuestionBank.QuizData quizData) {
        super(class_2561.method_43470("Quiz Question"));
        this.quizData = quizData;
        this.answers = quizData.getAllAnswers();
        this.correctAnswerIndex = quizData.getCorrectIndex();
    }
    
    @Override
    protected void method_25426() {
        super.method_25426();
        answerPanels.clear();
        
        int totalAnswers = answers.size();
        int columns = Math.min(GRID_COLUMNS, totalAnswers);
        int rows = class_3532.method_15386((float) totalAnswers / columns);
        
        // Calculate panel dimensions based on grid layout
        int availableWidth = (int)(field_22789 * 0.9); // Increased from 0.8 to 0.9 (90% of screen width)
        int panelWidth = (availableWidth / columns) - (PANEL_MARGIN * 2);
        int panelHeight = 60; // Fixed height for now
        
        // Calculate starting position (centered)
        int startX = (field_22789 - availableWidth) / 2;
        int startY = field_22790 / 3 + 30; // Below question text
        
        // Create answer panels
        for (int i = 0; i < answers.size(); i++) {
            int column = i % columns;
            int row = i / columns;
            
            int x = startX + column * (panelWidth + PANEL_MARGIN * 2);
            int y = startY + row * (panelHeight + PANEL_MARGIN);
            
            AnswerPanel panel = new AnswerPanel(
                x, y, panelWidth, panelHeight,
                answers.get(i), i
            );
            
            answerPanels.add(panel);
        }
    }
    
    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_25420(context, mouseX, mouseY, delta);
        
        // Draw question
        String question = quizData.getQuestion();
        
        // Use word wrapping for long questions
        class_2561 questionText = class_2561.method_43470(question);
        List<class_5481> wrappedOrderedTexts = field_22793.method_1728(questionText, field_22789 - 40);
        
        int lineY = field_22790 / 6; // Move question text higher
        for (class_5481 orderedText : wrappedOrderedTexts) {
            context.method_35719(field_22793, orderedText, field_22789 / 2, lineY, 0xFFFFFF);
            lineY += field_22793.field_2000 + 2;
        }
        
        // Draw answer panels
        for (AnswerPanel panel : answerPanels) {
            panel.render(context, mouseX, mouseY);
        }
        
        // Draw result message if showing result
        if (showingResult) {
            String resultMessage = isCorrect ? 
                "§a✓ Correct! §r" :
                "§c✗ Wrong! §r";
                
            class_2561 resultText = class_2561.method_43470(resultMessage);
            context.method_35719(
                field_22793,
                resultText.method_30937(), 
                field_22789 / 2, 
                field_22790 - 50, 
                0xFFFFFF
            );
            
            // Check if it's time to close the screen
            long currentTime = System.currentTimeMillis();
            if (isCorrect && (currentTime - resultDisplayStartTime > 500)) {
                method_25419();
            }
            else if (!isCorrect && (currentTime - resultDisplayStartTime > RESULT_DISPLAY_DURATION)) {
                method_25419();
            }
        }
    }
    
    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (!showingResult && button == 0) { // Left click
            for (AnswerPanel panel : answerPanels) {
                if (panel.isHovered((int)mouseX, (int)mouseY)) {
                    // Handle answer selection
                    selectedAnswerIndex = panel.index;
                    isCorrect = (selectedAnswerIndex == correctAnswerIndex);
                    showingResult = true;
                    resultDisplayStartTime = System.currentTimeMillis();
                    
                    // Send answer to server
                    StudycraftNetworking.sendAnswerPacket(isCorrect ? 0 : 1, quizData.getQuestion(), quizData.getCorrectAnswer());
                    return true;
                }
            }
        }
        return super.method_25402(mouseX, mouseY, button);
    }
    
    @Override
    public void method_25393() {
        super.method_25393();
        
        // Check if we need to close the screen
        if (showingResult && System.currentTimeMillis() - resultDisplayStartTime > RESULT_DISPLAY_DURATION) {
            method_25419();
        }
    }
    
    @Override
    public boolean method_25421() {
        return false;
    }
    
    /**
     * Custom panel class to replace buttons with better text wrapping
     */
    private class AnswerPanel {
        private final int x, y, width, height;
        private final String text;
        private final int index;
        private static final int TEXT_PADDING = 10;
        
        public AnswerPanel(int x, int y, int width, int height, String text, int index) {
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
            this.text = text;
            this.index = index;
        }
        
        public void render(class_332 context, int mouseX, int mouseY) {
            // Determine background color based on state
            int bgColor;
            boolean hovered = isHovered(mouseX, mouseY);
            
            if (showingResult) {
                if (index == selectedAnswerIndex) {
                    bgColor = isCorrect ? 0xFF00AA00 : 0xFFAA0000; // Green if correct, red if wrong
                } else if (index == correctAnswerIndex && !isCorrect) {
                    bgColor = 0xFF00AA00; // Green for correct answer when wrong answer selected
                } else {
                    bgColor = 0xFF505050; // Dark gray for unselected answers
                }
            } else {
                bgColor = hovered ? 0xFF707070 : 0xFF505050; // Lighter gray when hovered
            }
            
            // Draw panel background
            context.method_25294(x, y, x + width, y + height, bgColor);
            
            // Draw border
            context.method_49601(x, y, width, height, hovered ? 0xFFFFFFFF : 0xFF888888);
            
            // Prepare text for rendering
            class_2561 answerText = class_2561.method_43470(text);
            List<class_5481> wrappedText = field_22793.method_1728(answerText, width - (TEXT_PADDING * 2));
            
            // Calculate text scaling if needed
            float scale = 1.0f;  // Default scale
            int totalTextHeight = wrappedText.size() * (field_22793.field_2000 + 2) - 2;
            
            // If text height exceeds available height, scale it down
            if (totalTextHeight > height - (TEXT_PADDING * 2)) {
                scale = (float)(height - (TEXT_PADDING * 2)) / totalTextHeight;
                // Limit the minimum scale to ensure text isn't too small
                scale = Math.max(0.6f, scale);
            }
            
            // Save matrix state before scaling
            context.method_51448().method_22903();
            
            // Apply scaling if needed
            if (scale < 1.0f) {
                // Move to panel center, apply scale, then move back
                float centerX = x + width / 2.0f;
                float centerY = y + height / 2.0f;
                context.method_51448().method_46416(centerX, centerY, 0);
                context.method_51448().method_22905(scale, scale, 1.0f);
                context.method_51448().method_46416(-centerX, -centerY, 0);
            }
            
            // Calculate text Y position to center vertically
            int scaledTextHeight = (int)(totalTextHeight * scale);
            int textY = y + (height - scaledTextHeight) / 2;
            
            // Draw the text
            for (class_5481 line : wrappedText) {
                context.method_35720(field_22793, line, x + TEXT_PADDING, textY, 0xFFFFFF);
                textY += (field_22793.field_2000 + 2) * scale;
            }
            
            // Restore matrix state
            context.method_51448().method_22909();
        }
        
        public boolean isHovered(int mouseX, int mouseY) {
            return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
        }
    }
}