package bogget.studycraft;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.class_9334;
import java.util.Map;

public class StudycraftNetworking {

    // --- Payload Records ---

    public record OpenQuizPayload(String question, String answer1, String answer2, String answer3, String answer4, int correctIndex) implements class_8710 {
        public static final class_9154<OpenQuizPayload> ID = new class_9154<>(class_2960.method_60655(Studycraft.MOD_ID, "open_quiz"));
        public static final class_9139<class_2540, OpenQuizPayload> CODEC = class_9139.method_58025(
            class_9135.field_48554, OpenQuizPayload::question,
            class_9135.field_48554, OpenQuizPayload::answer1,
            class_9135.field_48554, OpenQuizPayload::answer2,
            class_9135.field_48554, OpenQuizPayload::answer3,
            class_9135.field_48554, OpenQuizPayload::answer4,
            class_9135.field_48550, OpenQuizPayload::correctIndex,
            OpenQuizPayload::new
        );
        @Override public class_9154<OpenQuizPayload> method_56479() { return ID; }
    }

    public record SubmitAnswerPayload(int result, String question, String correctAnswer) implements class_8710 {
        public static final class_9154<SubmitAnswerPayload> ID = new class_9154<>(class_2960.method_60655(Studycraft.MOD_ID, "submit_answer"));
        public static final class_9139<class_2540, SubmitAnswerPayload> CODEC = class_9139.method_56436(
            class_9135.field_48550, SubmitAnswerPayload::result,
            class_9135.field_48554, SubmitAnswerPayload::question,
            class_9135.field_48554, SubmitAnswerPayload::correctAnswer,
            SubmitAnswerPayload::new
        );
        @Override public class_9154<SubmitAnswerPayload> method_56479() { return ID; }
    }

    public record UpdateQuestionBankPayload(String content) implements class_8710 {
        public static final class_9154<UpdateQuestionBankPayload> ID = new class_9154<>(class_2960.method_60655(Studycraft.MOD_ID, "update_question_bank"));
        public static final class_9139<class_2540, UpdateQuestionBankPayload> CODEC = class_9139.method_56434(
            class_9135.field_48554, UpdateQuestionBankPayload::content,
            UpdateQuestionBankPayload::new
        );
        @Override public class_9154<UpdateQuestionBankPayload> method_56479() { return ID; }
    }

    public record RequestStatsPayload() implements class_8710 {
        public static final class_9154<RequestStatsPayload> ID = new class_9154<>(class_2960.method_60655(Studycraft.MOD_ID, "request_stats"));
        public static final class_9139<class_2540, RequestStatsPayload> CODEC = class_9139.method_56431(new RequestStatsPayload());
        @Override public class_9154<RequestStatsPayload> method_56479() { return ID; }
    }

    public record GiveItemPayload() implements class_8710 {
        public static final class_9154<GiveItemPayload> ID = new class_9154<>(class_2960.method_60655(Studycraft.MOD_ID, "give_item"));
        public static final class_9139<class_2540, GiveItemPayload> CODEC = class_9139.method_56431(new GiveItemPayload());
        @Override public class_9154<GiveItemPayload> method_56479() { return ID; }
    }

    public record DifficultyUpdatePayload(int hungerInterval, int hungerGain) implements class_8710 {
        public static final class_9154<DifficultyUpdatePayload> ID = new class_9154<>(class_2960.method_60655(Studycraft.MOD_ID, "difficulty_update"));
        public static final class_9139<class_2540, DifficultyUpdatePayload> CODEC = class_9139.method_56435(
            class_9135.field_48550, DifficultyUpdatePayload::hungerInterval,
            class_9135.field_48550, DifficultyUpdatePayload::hungerGain,
            DifficultyUpdatePayload::new
        );
        @Override public class_9154<DifficultyUpdatePayload> method_56479() { return ID; }
    }

    public record StatsDataPayload(String statsJson, float overallPercent) implements class_8710 {
        public static final class_9154<StatsDataPayload> ID = new class_9154<>(class_2960.method_60655(Studycraft.MOD_ID, "stats_data"));
        public static final class_9139<class_2540, StatsDataPayload> CODEC = class_9139.method_56435(
            class_9135.field_48554, StatsDataPayload::statsJson,
            class_9135.field_48552, StatsDataPayload::overallPercent,
            StatsDataPayload::new
        );
        @Override public class_9154<StatsDataPayload> method_56479() { return ID; }
    }

    // --- Registration ---

    public static void registerPayloads() {
        // Server-bound (client → server)
        PayloadTypeRegistry.playC2S().register(SubmitAnswerPayload.ID, SubmitAnswerPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(UpdateQuestionBankPayload.ID, UpdateQuestionBankPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(RequestStatsPayload.ID, RequestStatsPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(GiveItemPayload.ID, GiveItemPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(DifficultyUpdatePayload.ID, DifficultyUpdatePayload.CODEC);

        // Client-bound (server → client)
        PayloadTypeRegistry.playS2C().register(OpenQuizPayload.ID, OpenQuizPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(StatsDataPayload.ID, StatsDataPayload.CODEC);
    }

    public static void registerHandlers() {
        ServerPlayNetworking.registerGlobalReceiver(SubmitAnswerPayload.ID, (payload, context) -> {
            context.server().execute(() -> handleSubmitAnswer(payload, context.player()));
        });
        ServerPlayNetworking.registerGlobalReceiver(UpdateQuestionBankPayload.ID, (payload, context) -> {
            context.server().execute(() -> Studycraft.updateQuestionBank(payload.content()));
        });
        ServerPlayNetworking.registerGlobalReceiver(RequestStatsPayload.ID, (payload, context) -> {
            context.server().execute(() -> handleRequestStats(context.player()));
        });
        ServerPlayNetworking.registerGlobalReceiver(GiveItemPayload.ID, (payload, context) -> {
            context.server().execute(() -> handleGiveItem(context.player()));
        });
        ServerPlayNetworking.registerGlobalReceiver(DifficultyUpdatePayload.ID, (payload, context) -> {
            context.server().execute(() -> {
                Studycraft.setServerHungerInterval(payload.hungerInterval());
                Studycraft.setServerHungerGain(payload.hungerGain());
            });
        });
    }

    public static void registerClientHandlers() {
        ClientPlayNetworking.registerGlobalReceiver(OpenQuizPayload.ID, (payload, context) -> {
            context.client().execute(() -> {
                QuestionBank.QuizData quizData = new QuestionBank.QuizData(
                    payload.question(),
                    payload.answer1(),
                    java.util.List.of(payload.answer1(), payload.answer2(), payload.answer3(), payload.answer4()),
                    payload.correctIndex()
                );
                class_310.method_1551().method_1507(new QuizScreen(quizData));
            });
        });
        ClientPlayNetworking.registerGlobalReceiver(StatsDataPayload.ID, (payload, context) -> {
            context.client().execute(() -> handleStatsData(payload));
        });
    }

    // --- Server-side packet sending ---

    public static void sendOpenQuizPacket(class_3222 player) {
        QuestionBank.QuizData quizData = Studycraft.getQuestionBank().getRandomQuestion();
        if (quizData == null) return;
        java.util.List<String> answers = quizData.getAllAnswers();
        ServerPlayNetworking.send(player, new OpenQuizPayload(
            quizData.getQuestion(),
            answers.get(0), answers.get(1), answers.get(2), answers.get(3),
            quizData.getCorrectIndex()
        ));
    }

    // --- Client-side packet sending ---

    public static void sendAnswerPacket(int result, String question, String correctAnswer) {
        ClientPlayNetworking.send(new SubmitAnswerPayload(result, question, correctAnswer));
    }

    public static void sendUpdateQuestionBankPacket(String content) {
        ClientPlayNetworking.send(new UpdateQuestionBankPayload(content));
    }

    public static void requestStats() {
        ClientPlayNetworking.send(new RequestStatsPayload());
    }

    public static void sendGiveItemPacket() {
        ClientPlayNetworking.send(new GiveItemPayload());
    }

    public static void sendDifficultyUpdatePacket(int hungerInterval, int hungerGain) {
        ClientPlayNetworking.send(new DifficultyUpdatePayload(hungerInterval, hungerGain));
    }

    // --- Handlers ---

    private static void handleSubmitAnswer(SubmitAnswerPayload payload, class_3222 player) {
        boolean isCorrect = payload.result() == 0;
        QuizStatistics stats = Studycraft.getQuizStatistics();
        if (stats != null) {
            stats.recordAnswer(player.method_5667(), payload.question(), isCorrect);
        }
        if (isCorrect) {
            int gain = Studycraft.getServerHungerGain();
            player.method_7344().method_7585(gain, 0.5f);
            player.method_7353(class_2561.method_43470("§a[StudyCraft]§r Correct! +" + (gain / 2.0) + " drumsticks"), true);
        } else {
            player.method_7353(class_2561.method_43470("§c[StudyCraft]§r Wrong! The answer was: " + payload.correctAnswer()), true);
        }
    }

    private static void handleRequestStats(class_3222 player) {
        QuizStatistics stats = Studycraft.getQuizStatistics();
        if (stats == null) return;
        Map<String, QuizStatistics.StatsEntry> allStats = stats.getAllStats(player.method_5667());
        float overallPercent = stats.getOverallPercentCorrect(player.method_5667());

        // Serialize stats to JSON string simply
        StringBuilder json = new StringBuilder("{");
        boolean first = true;
        for (Map.Entry<String, QuizStatistics.StatsEntry> entry : allStats.entrySet()) {
            if (!first) json.append(",");
            String escapedKey = entry.getKey().replace("\"", "\\\"");
            QuizStatistics.StatsEntry s = entry.getValue();
            json.append("\"").append(escapedKey).append("\":")
                .append("{\"correct\":").append(s.getTimesCorrect())
                .append(",\"wrong\":").append(s.getTimesWrong()).append("}");
            first = false;
        }
        json.append("}");

        ServerPlayNetworking.send(player, new StatsDataPayload(json.toString(), overallPercent));
    }

    private static void handleGiveItem(class_3222 player) {
        class_1799 quizCard = new class_1799(Studycraft.QUIZ_ITEM);
        quizCard.method_57379(class_9334.field_49631, class_2561.method_43470("Quiz Card"));
        player.method_31548().method_7394(quizCard);
    }

    private static void handleStatsData(StatsDataPayload payload) {
        // Parse the simple JSON and update client stats
        // This is a simple parser for our specific format
        Map<String, QuizStatistics.StatsEntry> statsMap = new java.util.HashMap<>();
        try {
            String json = payload.statsJson().trim();
            if (json.equals("{}")) {
                Studycraft.getClientStats().updateStats(statsMap, payload.overallPercent());
                return;
            }
            // Remove outer braces
            json = json.substring(1, json.length() - 1);
            // Split by "}," to get individual entries
            String[] entries = json.split("\\},");
            for (String entry : entries) {
                entry = entry.trim().replace("}", "");
                int colonIdx = entry.indexOf("\":{");
                if (colonIdx < 0) continue;
                String key = entry.substring(1, colonIdx).replace("\\\"", "\"");
                String values = entry.substring(colonIdx + 3);
                int correct = 0, wrong = 0;
                for (String part : values.split(",")) {
                    if (part.contains("\"correct\":")) correct = Integer.parseInt(part.split(":")[1].trim());
                    if (part.contains("\"wrong\":")) wrong = Integer.parseInt(part.split(":")[1].trim());
                }
                statsMap.put(key, new QuizStatistics.StatsEntry(correct, wrong));
            }
        } catch (Exception e) {
            Studycraft.LOGGER.error("Failed to parse stats JSON", e);
        }
        Studycraft.getClientStats().updateStats(statsMap, payload.overallPercent());

        class_310 client = class_310.method_1551();
        if (client.field_1755 instanceof StudycraftConfigScreen screen) {
            screen.onStatsReceived();
        }
    }
}