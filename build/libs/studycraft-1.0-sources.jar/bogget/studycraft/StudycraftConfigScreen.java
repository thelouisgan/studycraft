package bogget.studycraft;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7919;
import bogget.studycraft.QuestionBankTextFieldWidget;

public class StudycraftConfigScreen extends class_437 {
    private final class_437 parent;
    private class_342 textField;
    private boolean showingStats = false;
    private boolean statsLoaded = false;
    private List<Map.Entry<String, QuizStatistics.StatsEntry>> statsList = new ArrayList<>();
    private int scrollOffset = 0;
    private static final int LINES_PER_PAGE = 5;
    
    // Store the original raw content separately
    private String rawQuestionBankContent = "";
    
    // Static fields to maintain difficulty state across screen instances
    private static int persistentHungerInterval = 40; // Default 2 seconds (40 ticks)
    private static int persistentHungerGain = 2; // Default 2 hunger points (1 drumstick)
    private static int persistentDifficultyIndex = 1; // Default to Normal
    
    // Instance fields that sync with persistent state
    private int currentHungerInterval;
    private int currentHungerGain;
    private int currentDifficultyIndex;
    
    // Clickable area for attribution
    private int attributionX = 20;
    private int attributionY = 27;
    private int attributionWidth;
    private int attributionHeight;
    private class_2561 attributionText = class_2561.method_43470("ganlouis.com · hack club");
    
    // Difficulty presets
    private static final DifficultyPreset[] DIFFICULTY_PRESETS = {
        new DifficultyPreset("Easy", 60, 3, "3 seconds between hunger loss, +1.5 drumsticks per correct answer"),
        new DifficultyPreset("Normal", 40, 2, "2 seconds between hunger loss, +1 drumstick per correct answer"),
        new DifficultyPreset("Hard", 30, 2, "1.5 seconds between hunger loss, +1 drumstick per correct answer"),
        new DifficultyPreset("Extreme", 20, 1, "1 second between hunger loss, +0.5 drumsticks per correct answer")
    };
    
    private void loadCurrentDifficultySettings() {
        // Load from persistent static fields
        this.currentHungerInterval = persistentHungerInterval;
        this.currentHungerGain = persistentHungerGain;
        this.currentDifficultyIndex = persistentDifficultyIndex;
        
        // Optionally, try to get current settings from the server/game state if available
        // Example: if (Studycraft.hasCurrentSettings()) {
        //     this.currentHungerInterval = Studycraft.getCurrentHungerInterval();
        //     this.currentHungerGain = Studycraft.getCurrentHungerGain();
        //     matchSettingsToPreset();
        // }
        
        // Match the loaded settings to the appropriate preset
        matchSettingsToPreset();
    }
    
    private void matchSettingsToPreset() {
        // Try to find which preset matches the current settings
        for (int i = 0; i < DIFFICULTY_PRESETS.length; i++) {
            DifficultyPreset preset = DIFFICULTY_PRESETS[i];
            if (preset.hungerInterval == currentHungerInterval && preset.hungerGain == currentHungerGain) {
                currentDifficultyIndex = i;
                return;
            }
        }
        
        // If no exact match found, default to Normal but keep the actual current values
        currentDifficultyIndex = 1;
    };
    

    
    public StudycraftConfigScreen(class_437 parent) {
        super(class_2561.method_43470("StudyCraft Configuration"));
        this.parent = parent;
        // Initialize with the actual raw content
        this.rawQuestionBankContent = QuestionBank.RAW_QUESTION_BANK;
        
        // Load current difficulty settings from the game state
        loadCurrentDifficultySettings();
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        
        // Calculate attribution text dimensions now that textRenderer is available
        this.attributionWidth = field_22793.method_27525(attributionText);
        this.attributionHeight = field_22793.field_2000;
        
        initTopRow();
        initMainButtons();

        if (showingStats) {
            initStatsView();
        } else {
            initQuestionBankEditor();
        }
    }
    
    private void initTopRow() {
        int buttonWidth = 120;
        int buttonHeight = 20;
        int spacing = 10;
        
        // Title positioned at top left
        // (Title will be drawn in render method)
        
        // Hunger Loss Button - top right
        String intervalText = String.format("Hunger Loss: %.1f", currentHungerInterval / 20.0);
        class_4185 hungerIntervalButton = class_4185.method_46430(
            class_2561.method_43470(intervalText),
            (button) -> {
                cycleDifficulty();
                updateDifficultySettings();
                // Refresh the screen to update button text
                method_37067();
                method_25426();
            }
        )
        .method_46434(field_22789 - buttonWidth * 2 - spacing - 10, 10, buttonWidth, buttonHeight)
        .method_46436(class_7919.method_47407(createHungerIntervalTooltip()))
        .method_46431();
        
        // Reward Button - top right, next to hunger loss
        String gainText = String.format("Reward: +%.1f", currentHungerGain / 2.0);
        class_4185 hungerGainButton = class_4185.method_46430(
            class_2561.method_43470(gainText),
            (button) -> {
                cycleDifficulty();
                updateDifficultySettings();
                // Refresh the screen to update button text
                method_37067();
                method_25426();
            }
        )
        .method_46434(field_22789 - buttonWidth - 10, 10, buttonWidth, buttonHeight)
        .method_46436(class_7919.method_47407(createHungerGainTooltip()))
        .method_46431();
        
        method_37063(hungerIntervalButton);
        method_37063(hungerGainButton);
    }
    
    private void cycleDifficulty() {
        currentDifficultyIndex = (currentDifficultyIndex + 1) % DIFFICULTY_PRESETS.length;
    }
    
    private void updateDifficultySettings() {
        DifficultyPreset preset = DIFFICULTY_PRESETS[currentDifficultyIndex];
        currentHungerInterval = preset.hungerInterval;
        currentHungerGain = preset.hungerGain;
        
        // Update persistent static fields
        persistentHungerInterval = currentHungerInterval;
        persistentHungerGain = currentHungerGain;
        persistentDifficultyIndex = currentDifficultyIndex;
        
        // Send the new settings to the server
        StudycraftNetworking.sendDifficultyUpdatePacket(currentHungerInterval, currentHungerGain);
        
        // Send chat message about difficulty change
        if (field_22787.field_1724 != null) {
            String intervalText = String.format("%.1f", currentHungerInterval / 20.0);
            String gainText = String.format("%.1f", currentHungerGain / 2.0);
            field_22787.field_1724.method_7353(class_2561.method_43470("§a[StudyCraft]§r Difficulty: " + preset.name + 
                " - Hunger interval: " + intervalText + "s, Reward: +" + gainText + " drumsticks"), false);
        }
    }
    
    private class_2561 createHungerIntervalTooltip() {
        DifficultyPreset current = DIFFICULTY_PRESETS[currentDifficultyIndex];
        return class_2561.method_43470(String.format("Difficulty: %s\n\n%s\n\nClick to cycle through difficulties", 
            current.name, current.description));
    }
    
    private class_2561 createHungerGainTooltip() {
        DifficultyPreset current = DIFFICULTY_PRESETS[currentDifficultyIndex];
        return class_2561.method_43470(String.format("Difficulty: %s\n\n%s\n\nClick to cycle through difficulties", 
            current.name, current.description));
    }
    
    private void initQuestionBankEditor() {
        // Clear only the content area widgets, keep main buttons and top row buttons
        removeContentWidgets();

        textField = new QuestionBankTextFieldWidget(
            field_22787.field_1772,
            field_22789 / 2 - (field_22789 - 40)/2,
            85, // Position below the main navigation buttons
            field_22789 - 40,
            field_22790 - 145  // Leave space for bottom buttons
        );
        
        // Set the text field to display the raw content properly
        textField.method_1852(rawQuestionBankContent);
        
        // Enable multiline support
        textField.method_1880(65536); // Increase max length for large question banks
        
        method_37063(textField);

        // Save Question Bank button - bottom left
        method_37063(class_4185.method_46430(
            class_2561.method_43470("Save Question Bank"),
            button -> {
                // Get the raw text from the field and update our stored content
                rawQuestionBankContent = textField.method_1882();
                
                // Send the raw content to the server
                StudycraftNetworking.sendUpdateQuestionBankPacket(rawQuestionBankContent);
                field_22787.field_1724.method_7353(class_2561.method_43470("§a[StudyCraft]§r Saved!"), false);
            })
            //.dimensions(20, height - 55, 150, 20)
            .method_46434(field_22789 / 2 - 150 - 5, field_22790 - 55, 150, 20)
            .method_46431()
        );

        // Give Quiz Card button - bottom right
        method_37063(class_4185.method_46430(
            class_2561.method_43470("Give Quiz Card"),
            button -> {
                if (field_22787.field_1724 != null) {
                    StudycraftNetworking.sendGiveItemPacket();
                    field_22787.field_1724.method_7353(class_2561.method_43470("§a[StudyCraft]§r Quiz card added to inventory!"), false);
                }
            })
            //.dimensions(width - 170, height - 55, 150, 20)
            .method_46434(field_22789 / 2 + 5, field_22790 - 55, 150, 20)
            .method_46431()
        );
    }

    private void initMainButtons() {
        int buttonWidth = 150;
        int buttonY = 40; // Position below the top row
        
        // Edit Question Bank button - center left
        class_4185 editorButton = class_4185.method_46430(
            class_2561.method_43470("Edit Question Bank"),
            (button) -> {
                showingStats = false;
                // Refresh the raw content from the current question bank
                rawQuestionBankContent = QuestionBank.RAW_QUESTION_BANK;
                method_37067();
                method_25426();
            }
        )
        .method_46434(field_22789 / 2 - buttonWidth - 5, buttonY, buttonWidth, 20)
        .method_46431();
        
        // View Statistics button - center right
        class_4185 statsButton = class_4185.method_46430(
            class_2561.method_43470("View Statistics"),
            (button) -> {
                if (!showingStats) {
                    showingStats = true;
                    statsLoaded = false; // Reset stats loaded flag
                    loadStats();
                    method_37067();
                    method_25426();
                }
            }
        )
        .method_46434(field_22789 / 2 + 5, buttonY, buttonWidth, 20)
        .method_46431();
        
        // Done button - bottom center
        class_4185 doneButton = class_4185.method_46430(
            class_2561.method_43470("Done"),
            (button) -> field_22787.method_1507(parent)
        )
        .method_46434(field_22789 / 2 - 75, field_22790 - 30, 150, 20)
        .method_46431();
        
        method_37063(editorButton);
        method_37063(statsButton);
        method_37063(doneButton);
    }
    
    private void loadStats() {
        // Request stats from the server
        if (field_22787.field_1724 != null) {
            StudycraftNetworking.requestStats();
        }
    }
    
    private void initStatsView() {
        // Remove content area widgets but keep main buttons and top row buttons
        removeContentWidgets();
        
        // Add scroll buttons
        class_4185 scrollUpButton = class_4185.method_46430(
            class_2561.method_43470("↑"),
            (button) -> scrollUp()
        )
        .method_46434(field_22789 - 30, 85, 20, 20)
        .method_46431();
        
        class_4185 scrollDownButton = class_4185.method_46430(
            class_2561.method_43470("↓"),
            (button) -> scrollDown()
        )
        .method_46434(field_22789 - 30, field_22790 - 60, 20, 20)
        .method_46431();
        
        method_37063(scrollUpButton);
        method_37063(scrollDownButton);

        // Give Quiz Card button for stats view - centre
        method_37063(class_4185.method_46430(
            class_2561.method_43470("Give Quiz Card"),
            button -> {
                if (field_22787.field_1724 != null) {
                    StudycraftNetworking.sendGiveItemPacket();
                    field_22787.field_1724.method_7353(class_2561.method_43470("§a[StudyCraft]§r Quiz card added to inventory!"), false);
                }
            })
            .method_46434(field_22789 / 2 - 75, field_22790 - 55, 150, 20)
            .method_46431()
        );
    }
    
    private void scrollUp() {
        if (scrollOffset > 0) {
            scrollOffset--;
        }
    }
    
    private void scrollDown() {
        if (scrollOffset < Math.max(0, statsList.size() - LINES_PER_PAGE)) {
            scrollOffset++;
        }
    }
    
    private void removeContentWidgets() {
        // Store references to buttons we want to preserve
        List<class_4185> preservedButtons = new ArrayList<>();
        
        // Find and store the buttons to preserve
        for (var child : method_25396()) {
            if (child instanceof class_4185 button) {
                int buttonY = button.method_46427();
                // Keep top row buttons, main navigation buttons, and bottom done button
                if (buttonY == 10 || buttonY == 40 || buttonY == field_22790 - 30) {
                    preservedButtons.add(button);
                }
            }
        }
        
        // Clear all children
        method_37067();
        
        // Re-add the preserved buttons
        for (class_4185 button : preservedButtons) {
            method_37063(button);
        }
    }
    
    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        // Check if attribution text was clicked
        if (button == 0 && isPointOverAttribution(mouseX, mouseY)) {
            // Open the website
            class_156.method_668().method_670("https://ganlouis.com");
            return true;
        }
        
        return super.method_25402(mouseX, mouseY, button);
    }
    
    private boolean isPointOverAttribution(double mouseX, double mouseY) {
        return mouseX >= attributionX && mouseX <= attributionX + attributionWidth &&
               mouseY >= attributionY && mouseY <= attributionY + attributionHeight;
    }
    
    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (showingStats && statsLoaded && !statsList.isEmpty()) {
            if (verticalAmount > 0) {
                scrollUp();
            } else if (verticalAmount < 0) {
                scrollDown();
            }
            return true;
        }
        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }
    
    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_25420(context, mouseX, mouseY, delta);  // blur background
        
        super.method_25394(context, mouseX, mouseY, delta);  // draw buttons/widgets BEFORE text
        
        // Draw text ON TOP of everything
        context.method_27535(field_22793, this.field_22785, 20, 15, 0xFFFFFF);
        
        boolean isHovering = isPointOverAttribution(mouseX, mouseY);
        int textColor = isHovering ? 0xAAAAAA : 0x888888;
        context.method_27535(field_22793, attributionText, attributionX, attributionY, textColor);
        
        if (isHovering) {
            List<class_2561> tooltipLines = List.of(
                class_2561.method_43470("Made by Louis Gan"),
                class_2561.method_43470("a project by Hack Club, a global nonprofit"),
                class_2561.method_43470("network of high school computer hackers,"),
                class_2561.method_43470("makers and coders")
            );
            context.method_51434(field_22793, tooltipLines, (int)mouseX, (int)mouseY);
        }
        
        if (showingStats) {
            renderStatsView(context);
        } else {
            context.method_27535(field_22793,
                class_2561.method_43470("Paste exported Quizlet set (tab-separated) here:"),
                20, 70, 0xAAAAAA);
        }
    }
    
    private void renderStatsView(class_332 context) {
        if (!statsLoaded) {
            // Show loading message while stats are being fetched
            context.method_27534(field_22793, 
                class_2561.method_43470("Loading statistics..."), 
                field_22789 / 2, field_22790 / 2, 0xFFFFFF);
            return;
        }
        
        // Draw overall stats
        float overallPercent = Studycraft.getClientStats().getOverallPercent();
        context.method_27535(field_22793, 
            class_2561.method_43470(String.format("Overall: %.1f%% correct (%d/%d)", 
                overallPercent, 
                Studycraft.getClientStats().getTotalCorrect(), 
                Studycraft.getClientStats().getTotalAnswers())),
            20, 70, 0xFFFFFF);
        
        // Draw divider
        context.method_25294(20, 85, field_22789 - 20, 86, 0xFFAAAAAA);
        
        // Get stats entries sorted by question
        statsList = Studycraft.getClientStats().getSortedStats();
        
        if (statsList.isEmpty()) {
            context.method_27534(field_22793, 
                class_2561.method_43470("No statistics available yet. Answer some questions first!"), 
                field_22789 / 2, field_22790 / 2, 0xAAAAAA);
            return;
        }
        
        // Draw stats entries - paginated
        int y = 95;
        int endIndex = Math.min(scrollOffset + LINES_PER_PAGE, statsList.size());
        
        for (int i = scrollOffset; i < endIndex; i++) {
            Map.Entry<String, QuizStatistics.StatsEntry> entry = statsList.get(i);
            String question = entry.getKey();
            QuizStatistics.StatsEntry stats = entry.getValue();
            
            // Truncate long questions
            if (question.length() > 30) {
                question = question.substring(0, 27) + "...";
            }
            
            // Draw question
            context.method_27535(field_22793, class_2561.method_43470(question), 25, y, 0xFFFFFF);
            
            // Draw stats
            String statsText = String.format("✓ %d  ✗ %d  (%.1f%%)", 
                stats.getTimesCorrect(), stats.getTimesWrong(), stats.getPercentCorrect());
            
            context.method_27535(field_22793, class_2561.method_43470(statsText), 
                field_22789 / 2 + 5, y, 0xAAAAAA);
            
            // Progress bar background
            context.method_25294(25, y + 12, field_22789 - 35, y + 16, 0xFF333333);
            
            // Progress bar fill
            int fillWidth = (int)((field_22789 - 60) * stats.getPercentCorrect() / 100f);
            int color = getColorForPercentage(stats.getPercentCorrect());
            context.method_25294(25, y + 12, 25 + fillWidth, y + 16, color);
            
            y += 25;
        }
        
        // Pagination info
        if (statsList.size() > LINES_PER_PAGE) {
            String pageInfo = String.format("Showing %d-%d of %d", 
                scrollOffset + 1, 
                Math.min(scrollOffset + LINES_PER_PAGE, statsList.size()), 
                statsList.size());
            
            context.method_27534(field_22793, class_2561.method_43470(pageInfo), 
                field_22789 / 2, field_22790 - 80, 0xAAAAAA);
        }
    }
    
    private int getColorForPercentage(float percent) {
        if (percent >= 80) {
            return 0xFF00AA00; // Green
        } else if (percent >= 60) {
            return 0xFF88AA00; // Yellow-green
        } else if (percent >= 40) {
            return 0xFFAAAA00; // Yellow
        } else if (percent >= 20) {
            return 0xFFAA5500; // Orange
        } else {
            return 0xFFAA0000; // Red
        }
    }
    
    @Override
    public boolean method_25421() {
        return false;
    }
    
    // Method to be called when stats data is received
    public void onStatsReceived() {
        statsLoaded = true;
    }
    
    // Inner class for difficulty presets
    private static class DifficultyPreset {
        final String name;
        final int hungerInterval; // ticks between hunger depletion
        final int hungerGain; // hunger points gained per correct answer
        final String description;
        
        DifficultyPreset(String name, int hungerInterval, int hungerGain, String description) {
            this.name = name;
            this.hungerInterval = hungerInterval;
            this.hungerGain = hungerGain;
            this.description = description;
        }
    }
}