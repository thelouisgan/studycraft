package bogget.studycraft;

import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3222;

public class QuizItem extends class_1792 {
    
    public QuizItem(class_1793 settings) {
        super(settings);
    }
    
    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 player, class_1268 hand) {
        class_1799 itemStack = player.method_5998(hand);
        
        if (!world.field_9236) {
            // Server-side: Tell the client to open the quiz screen
            //player.sendMessage(Text.literal("§6[StudyCraft]§r Opening quiz question..."), false);
            
            // No sound here - moved to the answer handling when correct
            
            // Cast to ServerPlayerEntity for the networking method
            StudycraftNetworking.sendOpenQuizPacket((class_3222) player);
        }
        
        // Don't consume the item
        return class_1271.method_22427(itemStack);
    }
}