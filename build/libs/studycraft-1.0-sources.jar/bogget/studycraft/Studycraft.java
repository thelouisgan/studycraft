package bogget.studycraft;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_4174;
import net.minecraft.class_7923;
import net.minecraft.class_9334;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import org.apache.logging.log4j.core.jmx.Server;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Studycraft implements ModInitializer {
    public static final String MOD_ID = "studycraft";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static QuizStatistics quizStatistics;
    private static ClientStatistics clientStatistics = new ClientStatistics();

    // Server configuration variables
    private static int serverHungerInterval = 40; // Default: 2 seconds (40 ticks)
    private static int serverHungerGain = 4; // Default: 2 hunger points (1 drumstick)

    public static QuizStatistics getQuizStatistics() {
        return quizStatistics;
    }

    public static ClientStatistics getClientStats() {
        if (clientStatistics == null) {
            clientStatistics = new ClientStatistics();
        }
        return clientStatistics;
    }

    public static void updateQuestionBank(String newContent) {
        // Set the new content and reload questions
        QuestionBank newQuestionBank = new QuestionBank(newContent);
        setQuestionBank(newQuestionBank);
        LOGGER.info("Question bank updated with {} questions", newQuestionBank.getQuestionCount());
    }
    
    // Server configuration getters and setters
    public static int getServerHungerInterval() {
        return serverHungerInterval;
    }
    
    public static void setServerHungerInterval(int interval) {
        serverHungerInterval = interval;
        LOGGER.info("Server hunger interval set to {} ticks ({} seconds)", interval, interval / 20.0);
    }
    
    public static int getServerHungerGain() {
        return serverHungerGain;
    }
    
    public static void setServerHungerGain(int gain) {
        serverHungerGain = gain;
        LOGGER.info("Server hunger gain set to {} points ({} drumsticks)", gain, gain / 2.0);
    }
    
    private static QuestionBank questionBank;
    private int tickCounter = 0;
    private final int HUNGER_INTERVAL = 40; // 2 seconds (20 ticks per second)
    
    // Register our quiz item
    public static final QuizItem QUIZ_ITEM = new QuizItem(
        new class_1792.class_1793()
            .method_7889(64)
            .method_57349(class_9334.field_50075, new class_4174.class_4175()
                .method_19238(1)
                .method_19237(0.1f)
                .method_19241()
                .method_19242())
    );

    @Override
    public void onInitialize() {
        LOGGER.info("Initializing StudyCraft mod");

        // Initialize the question bank
        questionBank = new QuestionBank();
        LOGGER.info("Loaded {} questions from question bank", questionBank.getQuestionCount());

        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            quizStatistics = new QuizStatistics(server);
            LOGGER.info("Initialized quiz statistics");
        });

        // Register our item
        class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MOD_ID, "quiz_card"), QUIZ_ITEM);
        
        StudycraftNetworking.registerPayloads();
        StudycraftNetworking.registerHandlers();
        // Register server start event to send welcome message
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            LOGGER.info("StudyCraft server started!");
        });
        
        // Send message to player when they join
        net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            class_3222 player = handler.field_14140;
            player.method_7353(class_2561.method_43470("§6[StudyCraft]§r Welcome! Your hunger will deplete every " + 
                (serverHungerInterval / 20.0) + " seconds. Use quiz cards to earn food!"), false);
            player.method_7353(class_2561.method_43470("§6[StudyCraft]§r Loaded " + questionBank.getQuestionCount() + " study questions."), false);
            LOGGER.info("Player {} joined with StudyCraft active", player.method_5477().getString());
        });
        
        // Register server tick event to handle hunger depletion
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            tickCounter++;
            
            // Use the configurable hunger interval instead of hardcoded value
            if (tickCounter >= serverHungerInterval) {
                tickCounter = 0;
                
                // For each player, deplete hunger
                for (class_3222 player : server.method_3760().method_14571()) {
                    int prevFoodLevel = player.method_7344().method_7586();
                    
                    // Add exhaustion to deplete hunger by 1 point (half a drumstick)
                    player.method_7344().method_7583(4.0F);
                    
                    // Check if food level changed and log it
                    if (player.method_7344().method_7586() < prevFoodLevel) {
                        LOGGER.info("Player {} hunger depleted: {} -> {}", 
                            player.method_5477().getString(), 
                            prevFoodLevel, 
                            player.method_7344().method_7586());
                        
                        // Send message to player
                        player.method_7353(class_2561.method_43470("§6[StudyCraft]§r Your hunger decreased by 1!"), true);
                    }
                }
            }
        });
    }
    
    // Get access to the question bank
    public static QuestionBank getQuestionBank() {
        return questionBank;
    }

    public static void setQuestionBank(QuestionBank questionBank) {
        Studycraft.questionBank = questionBank;
    }
    
}