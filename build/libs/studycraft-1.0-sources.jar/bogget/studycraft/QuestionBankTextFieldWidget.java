package bogget.studycraft;

import bogget.studycraft.mixin.TextFieldWidgetAccessor;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_342;

public class QuestionBankTextFieldWidget extends class_342 {
    private static final int TEXT_PADDING = 4;
    private int scrollPosition = 0;
    private final int maxVisibleLines;
    private final class_310 client;
    
    // Cursor position tracking
    private int cursorLine = 0;
    private int cursorColumn = 0;
    private long lastBlinkTime = 0;
    private boolean cursorVisible = true;
    private static final long CURSOR_BLINK_RATE = 500; // milliseconds
    
    // Selection tracking
    private int selectionStart = -1;
    private int selectionEnd = -1;
    private int selectionStartLine = -1;
    private int selectionEndLine = -1;
    private boolean isDragging = false;
    private int dragStartPos = -1;
    
    // Line tracking
    private List<String> lines = new ArrayList<>();
    
    // Tab representation
    private static final String TAB_VISUAL = "    "; // 4 spaces for display only
    private static final char TAB_CHAR = '\t'; // Actual tab character for storage
    
    // Undo/Redo system
    private Stack<TextState> undoStack = new Stack<>();
    private Stack<TextState> redoStack = new Stack<>();
    private boolean isUndoRedoOperation = false; // Flag to prevent undo states during undo/redo
    private static final int MAX_UNDO_HISTORY = 100; // Limit history size
    
    // Text state class for undo/redo
    private static class TextState {
        final String text;
        final int cursorPosition;
        final int selectionStart;
        final int selectionEnd;
        
        TextState(String text, int cursorPosition, int selectionStart, int selectionEnd) {
            this.text = text;
            this.cursorPosition = cursorPosition;
            this.selectionStart = selectionStart;
            this.selectionEnd = selectionEnd;
        }
    }
    
    public QuestionBankTextFieldWidget(class_327 textRenderer, int x, int y, int width, int height) {
        super(textRenderer, x, y, width, height, class_2561.method_43470("Question Bank"));
        this.method_1880(Integer.MAX_VALUE);
        this.method_1888(true);
        this.maxVisibleLines = height / (textRenderer.field_2000 + 2);
        this.client = class_310.method_1551();
        updateLines();
        
        // Save initial state after everything is set up
        isUndoRedoOperation = true; // Prevent this from being saved as an undoable action
        saveUndoState();
        isUndoRedoOperation = false;
    }

    private boolean isPrimaryModifierPressed(int modifiers) {
        if (class_156.method_668() == class_156.class_158.field_1137) {
            // On Mac, use Command key (Super/Meta)
            return (modifiers & GLFW.GLFW_MOD_SUPER) != 0;
        } else {
            // On Windows/Linux, use Control key
            return (modifiers & GLFW.GLFW_MOD_CONTROL) != 0;
        }
    }
    
    /**
     * Saves current state to undo stack
     */
    private void saveUndoState() {
        if (isUndoRedoOperation) return; // Don't save state during undo/redo operations
        
        String currentText = this.method_1882();
        int currentCursor = this.method_1881();
        int currentSelStart = hasSelection() ? Math.min(selectionStart, selectionEnd) : -1;
        int currentSelEnd = hasSelection() ? Math.max(selectionStart, selectionEnd) : -1;
        
        // Don't save if state hasn't changed
        if (!undoStack.isEmpty()) {
            TextState lastState = undoStack.peek();
            if (lastState.text.equals(currentText) && 
                lastState.cursorPosition == currentCursor &&
                lastState.selectionStart == currentSelStart &&
                lastState.selectionEnd == currentSelEnd) {
                return;
            }
        }
        
        undoStack.push(new TextState(currentText, currentCursor, currentSelStart, currentSelEnd));
        
        // Limit undo history size
        if (undoStack.size() > MAX_UNDO_HISTORY) {
            undoStack.removeElementAt(0);
        }
        
        // Clear redo stack when new action is performed
        redoStack.clear();
    }
    
    /**
     * Performs undo operation
     */
    public boolean undo() {
        if (undoStack.size() <= 1) return false; // Keep at least one state (current)
        
        // Save current state to redo stack
        TextState currentState = new TextState(
            this.method_1882(), 
            this.method_1881(),
            hasSelection() ? Math.min(selectionStart, selectionEnd) : -1,
            hasSelection() ? Math.max(selectionStart, selectionEnd) : -1
        );
        redoStack.push(currentState);
        
        // Remove current state from undo stack
        undoStack.pop();
        
        // Get previous state
        TextState previousState = undoStack.peek();
        
        // Apply previous state
        isUndoRedoOperation = true;
        this.method_1852(previousState.text);
        this.setCursor(previousState.cursorPosition);
        
        // Restore selection
        if (previousState.selectionStart != -1 && previousState.selectionEnd != -1) {
            setSelection(previousState.selectionStart, previousState.selectionEnd);
        } else {
            clearSelection();
        }
        
        updateLines();
        isUndoRedoOperation = false;
        
        return true;
    }
    
    /**
     * Performs redo operation
     */
    public boolean redo() {
        if (redoStack.isEmpty()) return false;
        
        // Get next state from redo stack
        TextState nextState = redoStack.pop();
        
        // Save current state to undo stack
        saveUndoState();
        
        // Apply next state
        isUndoRedoOperation = true;
        this.method_1852(nextState.text);
        this.setCursor(nextState.cursorPosition);
        
        // Restore selection
        if (nextState.selectionStart != -1 && nextState.selectionEnd != -1) {
            setSelection(nextState.selectionStart, nextState.selectionEnd);
        } else {
            clearSelection();
        }
        
        updateLines();
        isUndoRedoOperation = false;
        
        return true;
    }
    
    /**
     * Checks if undo is available
     */
    public boolean canUndo() {
        return undoStack.size() > 1;
    }
    
    /**
     * Checks if redo is available
     */
    public boolean canRedo() {
        return !redoStack.isEmpty();
    }
    
    private void updateLines() {
        lines.clear();
        // Important: Use -1 to keep empty lines
        String[] textLines = this.method_1882().split("\n", -1);
        for (String line : textLines) {
            lines.add(line);
        }
        
        // Update cursor position based on selection
        updateCursorPosition();
        updateSelectionPositions();
    }
    
    private void updateCursorPosition() {
        int cursorPos = this.method_1881();
        int pos = 0;
        cursorLine = 0;
        cursorColumn = 0;
        
        for (String line : lines) {
            int lineLength = line.length();
            if (pos + lineLength >= cursorPos) {
                cursorColumn = cursorPos - pos;
                break;
            }
            pos += lineLength + 1; // +1 for newline
            cursorLine++;
        }
        
        // Adjust scroll if cursor is out of view
        if (cursorLine < scrollPosition) {
            scrollPosition = cursorLine;
        } else if (cursorLine >= scrollPosition + maxVisibleLines) {
            scrollPosition = cursorLine - maxVisibleLines + 1;
        }
    }
    
    private void updateSelectionPositions() {
        if (selectionStart == -1 || selectionEnd == -1) {
            selectionStartLine = -1;
            selectionEndLine = -1;
            return;
        }
        
        // Calculate start position
        int pos = 0;
        selectionStartLine = 0;
        
        for (String line : lines) {
            int lineLength = line.length();
            if (pos + lineLength >= selectionStart) {
                break;
            }
            pos += lineLength + 1; // +1 for newline
            selectionStartLine++;
        }
        
        // Calculate end position
        pos = 0;
        selectionEndLine = 0;
        
        for (String line : lines) {
            int lineLength = line.length();
            if (pos + lineLength >= selectionEnd) {
                break;
            }
            pos += lineLength + 1; // +1 for newline
            selectionEndLine++;
        }
    }
    
    private void setSelection(int start, int end) {
        if (start > end) {
            int temp = start;
            start = end;
            end = temp;
        }
        
        selectionStart = start;
        selectionEnd = end;
        updateSelectionPositions();
        
        // Reset cursor blink when selection changes
        lastBlinkTime = System.currentTimeMillis();
        cursorVisible = true;
    }
    
    private void clearSelection() {
        selectionStart = selectionEnd = -1;
        selectionStartLine = -1;
        selectionEndLine = -1;
    }
    
    private boolean hasSelection() {
        return selectionStart != -1 && selectionEnd != -1 && selectionStart != selectionEnd;
    }
    
    public String method_1866() {
        if (!hasSelection()) return "";
        String text = this.method_1882();
        return text.substring(Math.min(selectionStart, selectionEnd), Math.max(selectionStart, selectionEnd));
    }
    
    private void deleteSelection() {
        if (!hasSelection()) return;
        
        int start = Math.min(selectionStart, selectionEnd);
        int end = Math.max(selectionStart, selectionEnd);
        
        String currentText = this.method_1882();
        String newText = currentText.substring(0, start) + currentText.substring(end);
        
        this.method_1852(newText);
        this.setCursor(start);
        clearSelection();
    }
    
    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == 0 && this.method_25405(mouseX, mouseY)) { // Left click
            // Calculate which line was clicked
            int relativeY = (int)(mouseY - this.method_46427() - TEXT_PADDING);
            int lineHeight = ((TextFieldWidgetAccessor)(Object)this).getTextRenderer().field_2000 + 2;
            int clickedLineOffset = relativeY / lineHeight;
            int clickedLine = scrollPosition + clickedLineOffset;
            
            // Make sure the clicked line is valid
            if (clickedLine >= 0 && clickedLine < lines.size()) {
                // Calculate which column was clicked
                int relativeX = (int)(mouseX - this.method_46426() - TEXT_PADDING);
                String line = lines.get(clickedLine);
                int clickedColumn = 0;
                
                // Find the closest character position based on X coordinate
                class_327 textRenderer = ((TextFieldWidgetAccessor)(Object)this).getTextRenderer();
                
                // Convert tabs to visual representation for width calculation
                String displayLine = line.replace(String.valueOf(TAB_CHAR), TAB_VISUAL);
                
                if (relativeX > 0 && !displayLine.isEmpty()) {
                    int currentX = 0;
                    
                    // Iterate through each character to find the closest position
                    for (int i = 0; i <= displayLine.length(); i++) {
                        int charWidth = 0;
                        if (i < displayLine.length()) {
                            charWidth = textRenderer.method_1727(String.valueOf(displayLine.charAt(i)));
                        }
                        
                        // Check if click is closer to this position or the next
                        if (relativeX <= currentX + charWidth / 2) {
                            // Convert back from display position to actual position
                            clickedColumn = convertDisplayPositionToActual(line, i);
                            break;
                        }
                        
                        currentX += charWidth;
                        
                        // If we've reached the end of the line
                        if (i == displayLine.length()) {
                            clickedColumn = convertDisplayPositionToActual(line, i);
                            break;
                        }
                    }
                    
                    // Make sure column doesn't exceed line length
                    clickedColumn = Math.min(clickedColumn, line.length());
                } else if (relativeX <= 0) {
                    clickedColumn = 0;
                } else {
                    // Click is beyond the end of the line
                    clickedColumn = line.length();
                }
                
                // Calculate the absolute cursor position
                int newCursorPos = calculatePositionFromLineCol(clickedLine, clickedColumn);
                
                // Handle shift-click for selection
                if (GLFW.glfwGetKey(client.method_22683().method_4490(), GLFW.GLFW_KEY_LEFT_SHIFT) == GLFW.GLFW_PRESS ||
                    GLFW.glfwGetKey(client.method_22683().method_4490(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS) {
                    
                    if (!hasSelection()) {
                        // Start new selection from current cursor position
                        setSelection(this.method_1881(), newCursorPos);
                    } else {
                        // Extend existing selection
                        setSelection(selectionStart, newCursorPos);
                    }
                } else {
                    // Clear selection on normal click
                    clearSelection();
                    
                    // Start potential drag selection
                    isDragging = true;
                    dragStartPos = newCursorPos;
                }
                
                // Set the cursor position
                this.setCursor(newCursorPos);
                
                // Update internal cursor tracking
                cursorLine = clickedLine;
                cursorColumn = clickedColumn;
                
                // Reset cursor blink
                lastBlinkTime = System.currentTimeMillis();
                cursorVisible = true;
                
                // Focus the widget
                this.method_25365(true);
                
                return true;
            }
        }
        
        return super.method_25402(mouseX, mouseY, button);
    }
    
    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (button == 0 && isDragging && this.method_25405(mouseX, mouseY)) {
            // Calculate position under mouse
            int relativeY = (int)(mouseY - this.method_46427() - TEXT_PADDING);
            int lineHeight = ((TextFieldWidgetAccessor)(Object)this).getTextRenderer().field_2000 + 2;
            int draggedLineOffset = relativeY / lineHeight;
            int draggedLine = scrollPosition + draggedLineOffset;
            
            // Clamp to valid lines
            draggedLine = Math.max(0, Math.min(draggedLine, lines.size() - 1));
            
            if (draggedLine >= 0 && draggedLine < lines.size()) {
                // Calculate column
                int relativeX = (int)(mouseX - this.method_46426() - TEXT_PADDING);
                String line = lines.get(draggedLine);
                int draggedColumn = 0;
                
                class_327 textRenderer = ((TextFieldWidgetAccessor)(Object)this).getTextRenderer();
                String displayLine = line.replace(String.valueOf(TAB_CHAR), TAB_VISUAL);
                
                if (relativeX > 0 && !displayLine.isEmpty()) {
                    int currentX = 0;
                    for (int i = 0; i <= displayLine.length(); i++) {
                        int charWidth = 0;
                        if (i < displayLine.length()) {
                            charWidth = textRenderer.method_1727(String.valueOf(displayLine.charAt(i)));
                        }
                        
                        if (relativeX <= currentX + charWidth / 2) {
                            draggedColumn = convertDisplayPositionToActual(line, i);
                            break;
                        }
                        
                        currentX += charWidth;
                        
                        if (i == displayLine.length()) {
                            draggedColumn = convertDisplayPositionToActual(line, i);
                            break;
                        }
                    }
                    draggedColumn = Math.min(draggedColumn, line.length());
                } else if (relativeX <= 0) {
                    draggedColumn = 0;
                } else {
                    draggedColumn = line.length();
                }
                
                int draggedPos = calculatePositionFromLineCol(draggedLine, draggedColumn);
                
                // Update selection
                setSelection(dragStartPos, draggedPos);
                this.setCursor(draggedPos);
                
                // Update cursor tracking
                cursorLine = draggedLine;
                cursorColumn = draggedColumn;
            }
            
            return true;
        }
        
        return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
    }
    
    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        if (button == 0) {
            isDragging = false;
            dragStartPos = -1;
        }
        return super.method_25406(mouseX, mouseY, button);
    }
    
    /**
     * Converts a position in the display string (with visual tabs) back to actual position
     */
    private int convertDisplayPositionToActual(String actualLine, int displayPosition) {
        int actualPosition = 0;
        int displayPos = 0;
        
        for (int i = 0; i < actualLine.length() && displayPos < displayPosition; i++) {
            if (actualLine.charAt(i) == TAB_CHAR) {
                // Tab takes up 4 display positions but 1 actual position
                displayPos += TAB_VISUAL.length();
                if (displayPos > displayPosition) {
                    // Click was within the tab, so position cursor at the tab
                    break;
                }
            } else {
                displayPos++;
            }
            actualPosition++;
        }
        
        return actualPosition;
    }
    
    @Override
    public void method_1867(String text) {
        // Only save undo state for meaningful changes (not during undo/redo)
        if (!isUndoRedoOperation) {
            saveUndoState();
        }
        
        // If there's a selection, delete it first
        if (hasSelection()) {
            deleteSelection();
        }
        
        // Special handling for pasted text that might contain tabs and newlines
        if (text.length() > 1) {
            // This is likely a paste operation
            // Preserve tabs and newlines exactly as they appear
            String processedText = text;
            
            int cursorPos = this.method_1881();
            String currentText = this.method_1882();
            String newText = currentText.substring(0, cursorPos) + processedText + currentText.substring(cursorPos);
            
            isUndoRedoOperation = true; // Prevent setText from saving another undo state
            this.method_1852(newText);
            isUndoRedoOperation = false;
            this.setCursor(cursorPos + processedText.length());
            updateLines();
            return;
        }
        
        // Handle special characters in single character input
        if (text.equals("\n") || text.equals("\r") || text.equals("\r\n")) {
            // Handle Enter key by inserting a newline at the cursor position
            int cursorPos = this.method_1881();
            String currentText = this.method_1882();
            String newText = currentText.substring(0, cursorPos) + "\n" + currentText.substring(cursorPos);
            isUndoRedoOperation = true;
            this.method_1852(newText);
            isUndoRedoOperation = false;
            this.setCursor(cursorPos + 1);
            updateLines();
        } else if (text.equals("\t")) {
            // Handle Tab key by inserting a tab character at the cursor position
            int cursorPos = this.method_1881();
            String currentText = this.method_1882();
            String newText = currentText.substring(0, cursorPos) + String.valueOf(TAB_CHAR) + currentText.substring(cursorPos);
            isUndoRedoOperation = true;
            this.method_1852(newText);
            isUndoRedoOperation = false;
            this.setCursor(cursorPos + 1);
            updateLines();
        } else {
            super.method_1867(text);
            updateLines();
        }
    }
    
    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        boolean shiftPressed = (modifiers & GLFW.GLFW_MOD_SHIFT) != 0;
        // Use the new helper method to check for primary modifier key (Ctrl on Windows/Linux, Cmd on Mac)
        boolean primaryModPressed = isPrimaryModifierPressed(modifiers);
        
        // Handle Primary+Z (Undo) - Ctrl+Z on Windows/Linux, Cmd+Z on Mac
        if (keyCode == GLFW.GLFW_KEY_Z && primaryModPressed && !shiftPressed) {
            return undo();
        }
        
        // Handle Primary+Y or Primary+Shift+Z (Redo) - Ctrl+Y/Ctrl+Shift+Z on Windows/Linux, Cmd+Y/Cmd+Shift+Z on Mac
        if ((keyCode == GLFW.GLFW_KEY_Y && primaryModPressed) || 
            (keyCode == GLFW.GLFW_KEY_Z && primaryModPressed && shiftPressed)) {
            return redo();
        }
        
        // Handle Primary+A (Select All) - Ctrl+A on Windows/Linux, Cmd+A on Mac
        if (keyCode == GLFW.GLFW_KEY_A && primaryModPressed) {
            setSelection(0, this.method_1882().length());
            this.setCursor(this.method_1882().length());
            updateCursorPosition();
            return true;
        }
        
        // Handle Primary+C (Copy) - Ctrl+C on Windows/Linux, Cmd+C on Mac
        if (keyCode == GLFW.GLFW_KEY_C && primaryModPressed) {
            if (hasSelection()) {
                client.field_1774.method_1455(method_1866());
            }
            return true;
        }
        
        // Handle Primary+X (Cut) - Ctrl+X on Windows/Linux, Cmd+X on Mac
        if (keyCode == GLFW.GLFW_KEY_X && primaryModPressed) {
            if (hasSelection()) {
                saveUndoState();
                client.field_1774.method_1455(method_1866());
                deleteSelection();
                updateLines();
            }
            return true;
        }
        
        // Handle Primary+V (Paste) - Ctrl+V on Windows/Linux, Cmd+V on Mac
        if (keyCode == GLFW.GLFW_KEY_V && primaryModPressed) {
            String clipboard = client.field_1774.method_1460();
            if (clipboard != null) {
                this.method_1867(clipboard);
                return true;
            }
        }
        
        // Save undo state for destructive operations (but not during undo/redo)
        boolean isDestructiveOperation = (keyCode == GLFW.GLFW_KEY_DELETE || keyCode == GLFW.GLFW_KEY_BACKSPACE) && 
                                    (hasSelection() || this.method_1882().length() > 0);

        if (isDestructiveOperation && !isUndoRedoOperation) {
            saveUndoState();
        }
        
        // Handle Delete and Backspace with selection
        if ((keyCode == GLFW.GLFW_KEY_DELETE || keyCode == GLFW.GLFW_KEY_BACKSPACE) && hasSelection()) {
            deleteSelection();
            updateLines();
            return true;
        }
        
        // Handle arrow keys with selection
        if (keyCode == GLFW.GLFW_KEY_LEFT) {
            int currentPos = this.method_1881();
            int newPos = Math.max(0, currentPos - 1);
            
            if (shiftPressed) {
                if (!hasSelection()) {
                    setSelection(currentPos, newPos);
                } else {
                    setSelection(selectionStart, newPos);
                }
            } else {
                clearSelection();
            }
            
            this.setCursor(newPos);
            updateCursorPosition();
            return true;
        }
        
        if (keyCode == GLFW.GLFW_KEY_RIGHT) {
            int currentPos = this.method_1881();
            int newPos = Math.min(this.method_1882().length(), currentPos + 1);
            
            if (shiftPressed) {
                if (!hasSelection()) {
                    setSelection(currentPos, newPos);
                } else {
                    setSelection(selectionStart, newPos);
                }
            } else {
                clearSelection();
            }
            
            this.setCursor(newPos);
            updateCursorPosition();
            return true;
        }
        
        if (keyCode == GLFW.GLFW_KEY_UP) {
            if (cursorLine > 0) {
                int currentPos = this.method_1881();
                int targetPos = calculatePositionFromLineCol(cursorLine - 1, Math.min(cursorColumn, lines.get(cursorLine - 1).length()));
                
                if (shiftPressed) {
                    if (!hasSelection()) {
                        setSelection(currentPos, targetPos);
                    } else {
                        setSelection(selectionStart, targetPos);
                    }
                } else {
                    clearSelection();
                }
                
                this.setCursor(targetPos);
                updateCursorPosition();
                return true;
            }
        }
        
        if (keyCode == GLFW.GLFW_KEY_DOWN) {
            if (cursorLine < lines.size() - 1) {
                int currentPos = this.method_1881();
                int targetPos = calculatePositionFromLineCol(cursorLine + 1, Math.min(cursorColumn, lines.get(cursorLine + 1).length()));
                
                if (shiftPressed) {
                    if (!hasSelection()) {
                        setSelection(currentPos, targetPos);
                    } else {
                        setSelection(selectionStart, targetPos);
                    }
                } else {
                    clearSelection();
                }
                
                this.setCursor(targetPos);
                updateCursorPosition();
                return true;
            }
        }
        
        // Handle Home key
        if (keyCode == GLFW.GLFW_KEY_HOME) {
            int currentPos = this.method_1881();
            int lineStartPos = calculatePositionFromLineCol(cursorLine, 0);
            
            if (shiftPressed) {
                if (!hasSelection()) {
                    setSelection(currentPos, lineStartPos);
                } else {
                    setSelection(selectionStart, lineStartPos);
                }
            } else {
                clearSelection();
            }
            
            this.setCursor(lineStartPos);
            updateCursorPosition();
            return true;
        }
        
        // Handle End key
        if (keyCode == GLFW.GLFW_KEY_END) {
            int currentPos = this.method_1881();
            int lineEndPos = calculatePositionFromLineCol(cursorLine, lines.get(cursorLine).length());
            
            if (shiftPressed) {
                if (!hasSelection()) {
                    setSelection(currentPos, lineEndPos);
                } else {
                    setSelection(selectionStart, lineEndPos);
                }
            } else {
                clearSelection();
            }
            
            this.setCursor(lineEndPos);
            updateCursorPosition();
            return true;
        }
        
        // Handle regular keys that clear selection
        if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
            if (hasSelection()) {
                deleteSelection();
            }
            this.method_1867("\n");
            return true;
        } else if (keyCode == GLFW.GLFW_KEY_TAB) {
            if (hasSelection()) {
                deleteSelection();
            }
            this.method_1867("\t");
            return true;
        } else {
            // For other keys, if there's a selection and it's a character input, clear selection first
            boolean result = super.method_25404(keyCode, scanCode, modifiers);
            updateLines();
            return result;
        }
    }
    
    private int calculatePositionFromLineCol(int line, int column) {
        int pos = 0;
        for (int i = 0; i < line; i++) {
            pos += lines.get(i).length() + 1; // +1 for newline
        }
        return pos + column;
    }
    
    @Override
    public void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
        // Draw background
        context.method_25294(this.method_46426(), this.method_46427(), this.method_46426() + this.field_22758, this.method_46427() + this.field_22759, 0xFF000000);
        context.method_49601(this.method_46426(), this.method_46427(), this.field_22758, this.field_22759, 0xFFAAAAAA);
        
        // Get text renderer
        class_327 textRenderer = ((TextFieldWidgetAccessor)(Object)this).getTextRenderer();
        
        // Draw text lines with real newlines and tabs
        if (!lines.isEmpty()) {
            int endIndex = Math.min(scrollPosition + maxVisibleLines, lines.size());
            int y = this.method_46427() + TEXT_PADDING;
            
            for (int i = scrollPosition; i < endIndex; i++) {
                // Replace tab characters with visual representation for display only
                String displayLine = lines.get(i).replace(String.valueOf(TAB_CHAR), TAB_VISUAL);
                
                // Draw selection highlighting for this line
                if (hasSelection()) {
                    drawSelectionHighlight(context, textRenderer, i, y, displayLine);
                }
                
                // Draw the line
                context.method_51433(textRenderer, displayLine, this.method_46426() + TEXT_PADDING, y, 0xFFFFFF, false);
                y += textRenderer.field_2000 + 2;
            }
            
            // Draw cursor if this field has focus and is editable
            if (this.method_25370() && ((TextFieldWidgetAccessor)(Object)this).isEditable()) {
                // Update cursor blink
                long currentTime = System.currentTimeMillis();
                if (currentTime - lastBlinkTime > CURSOR_BLINK_RATE) {
                    cursorVisible = !cursorVisible;
                    lastBlinkTime = currentTime;
                }
                
                // Draw cursor if visible and in view (and no selection or cursor is at selection boundary)
                if (cursorVisible && cursorLine >= scrollPosition && cursorLine < scrollPosition + maxVisibleLines &&
                    (!hasSelection() || this.method_1881() == selectionStart || this.method_1881() == selectionEnd)) {
                    int cursorY = this.method_46427() + TEXT_PADDING + (cursorLine - scrollPosition) * (textRenderer.field_2000 + 2);
                    int cursorX = this.method_46426() + TEXT_PADDING;
                    
                    // Calculate cursor X position accounting for tabs
                    if (cursorColumn > 0) {
                        String textBeforeCursor = lines.get(cursorLine).substring(0, cursorColumn).replace(String.valueOf(TAB_CHAR), TAB_VISUAL);
                        cursorX += textRenderer.method_1727(textBeforeCursor);
                    }
                    
                    // Draw cursor line
                    context.method_25294(cursorX, cursorY, cursorX + 1, cursorY + textRenderer.field_2000, 0xFFFFFFFF);
                }
            }
            
            // Draw scroll indicators if needed
            if (lines.size() > maxVisibleLines) {
                // Up arrow if scrolled down
                if (scrollPosition > 0) {
                    context.method_51433(textRenderer, "▲", this.method_46426() + this.field_22758 - 10, this.method_46427() + 2, 0xFFFFFF, false);
                }
                
                // Down arrow if can scroll more
                if (scrollPosition + maxVisibleLines < lines.size()) {
                    context.method_51433(textRenderer, "▼", this.method_46426() + this.field_22758 - 10, this.method_46427() + this.field_22759 - 10, 0xFFFFFF, false);
                }
                
                // Draw scroll position indicator
                String scrollInfo = (scrollPosition + 1) + "-" + Math.min(scrollPosition + maxVisibleLines, lines.size()) + "/" + lines.size();
                context.method_51433(textRenderer, scrollInfo, this.method_46426() + this.field_22758 - textRenderer.method_1727(scrollInfo) - 4, 
                    this.method_46427() + this.field_22759 - textRenderer.field_2000 - 2, 0xAAAAAA, false);
            }
        }
    }
    
    private void drawSelectionHighlight(class_332 context, class_327 textRenderer, int lineIndex, int lineY, String displayLine) {
        // Check if this line has any selection
        if (selectionStartLine == -1 || selectionEndLine == -1) return;
        
        int actualSelStart = Math.min(selectionStart, selectionEnd);
        int actualSelEnd = Math.max(selectionStart, selectionEnd);
        
        if (actualSelStart == actualSelEnd) return;
        
        // Calculate line positions
        int lineStart = calculatePositionFromLineCol(lineIndex, 0);
        int lineEnd = calculatePositionFromLineCol(lineIndex, lines.get(lineIndex).length());
        
        // Check if selection intersects with this line
        if (actualSelEnd <= lineStart || actualSelStart >= lineEnd) return;
        
        // Calculate selection bounds within this line
        int selStartInLine = Math.max(0, actualSelStart - lineStart);
        int selEndInLine = Math.min(lines.get(lineIndex).length(), actualSelEnd - lineStart);
        
        if (selStartInLine >= selEndInLine) return;
        
        // Convert to display positions for proper tab handling
        String actualLine = lines.get(lineIndex);
        int displayStartPos = convertActualPositionToDisplay(actualLine, selStartInLine);
        int displayEndPos = convertActualPositionToDisplay(actualLine, selEndInLine);
        
        // Calculate X positions
        int selectionStartX = this.method_46426() + TEXT_PADDING;
        int selectionEndX = this.method_46426() + TEXT_PADDING;
        
        if (displayStartPos > 0) {
            String textBefore = displayLine.substring(0, Math.min(displayStartPos, displayLine.length()));
            selectionStartX += textRenderer.method_1727(textBefore);
        }
        
        if (displayEndPos > 0) {
            String textBefore = displayLine.substring(0, Math.min(displayEndPos, displayLine.length()));
            selectionEndX += textRenderer.method_1727(textBefore);
        }
        
        // If selection goes to end of line, extend to a reasonable width
        if (selEndInLine >= actualLine.length()) {
            selectionEndX += 4; // Small padding to show selection at line end
        }
        
        // Draw selection background
        context.method_25294(selectionStartX, lineY, selectionEndX, lineY + textRenderer.field_2000, 0x663366FF);
    }
    
    private int convertActualPositionToDisplay(String actualLine, int actualPosition) {
        int displayPosition = 0;
        
        for (int i = 0; i < Math.min(actualPosition, actualLine.length()); i++) {
            if (actualLine.charAt(i) == TAB_CHAR) {
                displayPosition += TAB_VISUAL.length();
            } else {
                displayPosition++;
            }
        }
        
        return displayPosition;
    }
    
    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        // Handle scrolling
        if (amount > 0 && scrollPosition > 0) {
            scrollPosition--;
            return true;
        } else if (amount < 0) {
            if (scrollPosition < lines.size() - maxVisibleLines) {
                scrollPosition++;
                return true;
            }
        }
        return false;
    }
    
    @Override
    public boolean method_25400(char chr, int modifiers) {
        // Only save undo state for printable characters and not during undo/redo
        if (chr >= 32 && !isUndoRedoOperation) {
            saveUndoState();
        }
        
        // Clear selection when typing regular characters
        if (hasSelection() && chr >= 32) { // Printable characters
            deleteSelection();
        }
        
        boolean result = super.method_25400(chr, modifiers);
        updateLines();
        return result;
    }
    
    public void setCursor(int cursor) {
        super.method_1883(cursor, false);
        updateCursorPosition();
    }
    
    @Override
    public void method_25365(boolean focused) {
        super.method_25365(focused);
        if (focused) {
            // Reset cursor blink when gaining focus
            lastBlinkTime = System.currentTimeMillis();
            cursorVisible = true;
        } else {
            // Clear selection when losing focus
            clearSelection();
        }
    }
    
    /**
     * Ensures tabs and newlines are preserved in the text
     */
    @Override
    public void method_1852(String text) {
        // Only save undo state if this is not an undo/redo operation and text is actually different
        if (!isUndoRedoOperation && !text.equals(this.method_1882())) {
            saveUndoState();
        }
        
        super.method_1852(text);
        clearSelection();
        updateLines();
    }
    
    /**
     * Make sure we return text with all tabs and newlines preserved
     */
    @Override
    public String method_1882() {
        String text = super.method_1882();
        return text;
    }
    
    /**
     * Clears all undo/redo history
     */
    public void clearHistory() {
        undoStack.clear();
        redoStack.clear();
        // Save current state as the new starting point
        saveUndoState();
    }
    
    /**
     * Gets the current number of undo operations available
     */
    public int getUndoCount() {
        return Math.max(0, undoStack.size() - 1);
    }
    
    /**
     * Gets the current number of redo operations available
     */
    public int getRedoCount() {
        return redoStack.size();
    }
}