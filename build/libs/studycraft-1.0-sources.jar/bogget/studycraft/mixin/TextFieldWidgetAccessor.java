package bogget.studycraft.mixin;

import net.minecraft.class_327;
import net.minecraft.class_342;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_342.class)
public interface TextFieldWidgetAccessor {
    @Accessor("textRenderer")
    class_327 getTextRenderer();

    @Accessor("editable")
    boolean isEditable();
}
